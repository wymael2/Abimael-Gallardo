import java.util.Scanner;

public class CalculadorLinealMultiX {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicitar los valores de a y b al usuario
        System.out.println("Calculadora de ecuación lineal Y = bX + a");
        System.out.print("Ingrese el valor del intercepto (a): ");
        float a = scanner.nextFloat();
        
        System.out.print("Ingrese el valor de la pendiente (b): ");
        float b = scanner.nextFloat();
        
        // Crear arreglo para 21 valores de X
        float[] xValues = new float[10];
        System.out.println("\nIngrese los 21 valores de X:");
        
        // Leer los 21 valores de X
        for (int i = 0; i < 10; i++) {
            System.out.print("X[" + (i + 1) + "]: ");
            xValues[i] = scanner.nextFloat();
        }
        
        // Calcular y mostrar los valores de Y
        System.out.println("\nResultados:");
        System.out.println("X\t\tY = " + b + " * X + " + a);
        System.out.println("--------------------------------");
        
        for (int i = 0; i < 10; i++) {
            float y = b * xValues[i] + a;
            System.out.printf("%.2f\t\t%.2f%n", xValues[i], y);
        }
        
        scanner.close();
    }
}