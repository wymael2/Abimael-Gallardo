import java.util.Scanner;

public class RegresionLinealFloat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        float[] x = new float[21];
        float[] y = new float[21];

        System.out.println("Ingrese los 21 valores de X:");
        for (int i = 0; i < 21; i++) {
            System.out.print("X[" + (i+1) + "]: ");
            x[i] = scanner.nextFloat();
        }

        System.out.println("\nIngrese los 21 valores de Y:");
        for (int i = 0; i < 21; i++) {
            System.out.print("Y[" + (i+1) + "]: ");
            y[i] = scanner.nextFloat();
        }

        // Calcular sumatorias
        float sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        for (int i = 0; i < 21; i++) {
            sumX += x[i];
            sumY += y[i];
            sumXY += x[i] * y[i];
            sumX2 += x[i] * x[i];
        }

        // Calcular pendiente (b) e intercepto (a)
        float n = 21;
        float b = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        float a = (sumY - b * sumX) / n;

        // Calcular R²
        float ssTotal = 0, ssResidual = 0;
        float yMean = sumY / n;
        for (int i = 0; i < 21; i++) {
            ssTotal += Math.pow(y[i] - yMean, 2);
            float yPred = a + b * x[i];
            ssResidual += Math.pow(y[i] - yPred, 2);
        }
        float r2 = 1 - (ssResidual / ssTotal);

        System.out.println("\nResultados de la Regresión Lineal:");
        System.out.printf("Ecuación: Y = %.4f + %.4fX%n", a, b);
        System.out.printf("Coeficiente de determinación (R²): %.4f%n", r2);
        System.out.printf("Intercepto (a): %.4f%n", a);
        System.out.printf("Pendiente (b): %.4f%n", b);

        scanner.close();
    }
}